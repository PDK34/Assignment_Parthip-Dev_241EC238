clc; clear;

img = imread('sunflower.jpg');    
imwrite(img, 'sunflower.png');


img = imread('sunflower.png');
img_g = rgb2gray(img);
img_noise = imnoise(img_g ,'gaussian' ,0.1);

g = fspecial('gaussian',[5,5],1.1);

img_filt = imfilter(img_noise,g);


psnr_n = psnr(img_noise, img_g);
psnr_f = psnr(img_noise, img_filt);

subplot(2,2,1);
imshow(img);
title('Original image(Grayscaled)');


subplot(2,2,2);
imshow(img_noise);
title(['Noisy Image (PSNR = ', num2str(psnr_n, '%.2f'), ' dB)']);

subplot(2,2,3);
imshow(img_filt);
title(['Filtered image(PSNR = ',num2str(psnr_f,'%.2f'),' dB)']);